create function time_bucket(bucket_width interval, ts timestamp without time zone, "offset" interval) returns timestamp without time zone
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.time_bucket(bucket_width, ts-"offset")+"offset";
$$;

alter function time_bucket(interval, timestamp, interval) owner to postgres;

