create function time_bucket(bucket_width interval, ts timestamp with time zone, "offset" interval) returns timestamp with time zone
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT public.time_bucket(bucket_width, ts-"offset")+"offset";
$$;

alter function time_bucket(interval, timestamp with time zone, interval) owner to postgres;

