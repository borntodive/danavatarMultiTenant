create
    definer = dsg@localhost procedure getBoxpolt()
BEGIN
	SELECT
	gradient_factor, gradient_factor_before_last
	FROM
	DivesInfo;

END;

