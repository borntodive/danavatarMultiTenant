create
    definer = dsg@localhost procedure DiveGases_copy1(IN user_id int)
BEGIN
	SELECT 
            COUNT(DivesInfo.id) as count,
            case 
               when GasSwitches.o2 = 21 and GasSwitches.he =0 then 'Air'
               when GasSwitches.o2 > 21 and GasSwitches.he =0 then 'Ntx'
							 when GasSwitches.o2 = 100 then 'Oxy'
               when GasSwitches.o2 + GasSwitches.he =100 and GasSwitches.he > 0 then 'Hex'
               else 'Tmx' 
               end as g_mix
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
                     INNER JOIN DivesProfile ON DivesInfo.id = DivesProfile.divesInfo_id
                     INNER JOIN GasSwitches ON DivesProfile.gasswitch_id = GasSwitches.id
            WHERE DivesGenInfo.user_id=user_id AND (apnea IS NULL)		AND (apparatus!=2 OR apparatus IS NULL ) AND DivesInfo.completed =1
            group by g_mix;
END;

