create
    definer = dsg@localhost procedure miniStats_copy1(IN user_id int)
BEGIN
           SELECT
                Avg(DivesInfo.max_depth) AS avg_depth,
                Avg(DivesInfo.dive_duration) AS avg_durat,
                Max(DivesInfo.max_depth) AS max_depth,
                Max(DivesInfo.dive_duration) AS max_durat,
                Sum(DivesInfo.dive_duration) AS tot_durat,
                Sum(DivesInfo.max_depth) AS tot_depth
                FROM
                DivesInfo
                INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
                WHERE
                DivesGenInfo.user_id =user_id AND DivesInfo.completed =1;
   
   
END;

