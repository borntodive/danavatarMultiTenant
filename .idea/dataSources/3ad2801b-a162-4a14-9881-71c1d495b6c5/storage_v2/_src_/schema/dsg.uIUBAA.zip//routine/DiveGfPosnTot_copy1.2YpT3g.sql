create
    definer = dsg@localhost procedure DiveGfPosnTot_copy1(IN max_gf double)
BEGIN
	
           SELECT DivesInfo.gradient_factor
FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
WHERE (apparatus!=2 OR apparatus IS NULL ) AND max_depth>10 AND dive_duration>5 AND gradient_factor>=0.2 AND gradient_factor<=max_gf AND DivesInfo.completed =1;
   
   
END;

