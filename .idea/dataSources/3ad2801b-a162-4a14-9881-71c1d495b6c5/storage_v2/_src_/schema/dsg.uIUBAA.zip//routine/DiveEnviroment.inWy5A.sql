create
    definer = dsg@localhost procedure DiveEnviroment(IN user_id int)
BEGIN
	
           SELECT 
            enviroment,
            COUNT(*) as count
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND enviroment IS NOT NULL AND DivesInfo.completed =1
            group by enviroment;

END;

