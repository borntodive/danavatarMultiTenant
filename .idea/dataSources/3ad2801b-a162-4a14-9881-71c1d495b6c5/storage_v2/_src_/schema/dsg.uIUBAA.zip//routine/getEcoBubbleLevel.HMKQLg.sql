create
    definer = dsg@localhost procedure getEcoBubbleLevel()
BEGIN
SELECT
	IFNULL(ROUND(time), 'total') AS time,
	IFNULL(eval, 'total_eval') AS eval,
	COUNT(DivesEcoEval.eval) as count
	FROM
	DivesEcoEval
	GROUP BY  eval ASC, time ASC
	WITH ROLLUP;
END;

