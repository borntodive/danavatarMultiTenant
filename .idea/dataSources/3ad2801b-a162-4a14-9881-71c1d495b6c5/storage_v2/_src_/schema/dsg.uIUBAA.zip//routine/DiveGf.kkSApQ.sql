create
    definer = dsg@localhost procedure DiveGf(IN user_id int, IN yellow_boundary double, IN red_boundary double)
BEGIN
	
           SELECT 
            COUNT(*) as count,
            case 
               when gradient_factor >= 0 and gradient_factor< yellow_boundary then 'g'
               when gradient_factor >= yellow_boundary and gradient_factor< red_boundary then 'y'
               else 'r' 
               end as gf_range
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND DivesInfo.completed =1
            group by gf_range;
END;

