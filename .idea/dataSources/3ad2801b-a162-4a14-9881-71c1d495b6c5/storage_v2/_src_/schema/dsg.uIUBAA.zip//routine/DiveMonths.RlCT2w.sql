create
    definer = dsg@localhost procedure DiveMonths(IN user_id int)
BEGIN
	
            SELECT MONTH(start_time) as month, 
            COUNT(*) as count
    FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
    WHERE DivesGenInfo.user_id=user_id AND DivesInfo.completed =1
    GROUP BY MONTH(start_time);

END;

