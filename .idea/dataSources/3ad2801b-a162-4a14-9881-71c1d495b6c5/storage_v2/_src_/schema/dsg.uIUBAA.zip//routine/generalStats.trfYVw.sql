create
    definer = dsg@localhost procedure generalStats()
BEGIN
	SELECT
		YEAR(start_time) as year,
		MAX(DivesInfo.max_depth) as M_depth,
		MIN(DivesInfo.max_depth) as m_depth,
		AVG(DivesInfo.max_depth) as avg_depth,
		SUM(DivesInfo.max_depth) as t_depth,
		MAX(DivesInfo.dive_duration) as M_runtime,
		MIN(DivesInfo.dive_duration) as m_runtime,
		AVG(DivesInfo.dive_duration) as avg_runtime,
		SUM(DivesInfo.dive_duration) as t_runtime,
		SUM(case when DivesInfo.completed = 1 then 1 else 0 end) as c_completed,
		SUM(case when DivesInfo.completed = 1 then 0 else 1 end) as c_uncompleted,
		COUNT(DivesInfo.id) as c_alldives
	FROM
		DivesInfo
	GROUP BY YEAR(start_time) WITH ROLLUP;

END;

