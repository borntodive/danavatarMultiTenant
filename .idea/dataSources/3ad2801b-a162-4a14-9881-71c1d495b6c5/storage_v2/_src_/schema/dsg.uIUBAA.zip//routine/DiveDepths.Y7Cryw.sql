create
    definer = dsg@localhost procedure DiveDepths(IN user_id int)
BEGIN
	
           SELECT 
            COUNT(*) as count,
            case 
               when max_depth >= 0 and max_depth< 10 then '0-9 mts'
               when max_depth >= 10 and max_depth< 20 then '10-19 mts'
               when max_depth >= 20 and max_depth< 30 then '20-29 mts'
               when max_depth >= 30 and max_depth< 40 then '30-39 mts'
               when max_depth >= 40 and max_depth< 50 then '40-49 mts'
               when max_depth >= 50 and max_depth< 60 then '50-59 mts'
               when max_depth >= 60 and max_depth< 70 then '60-69 mts'
               when max_depth >= 70 and max_depth< 80 then '70-79 mts'
               else '80+ mts' 
               end as d_range
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND DivesInfo.completed =1
            group by d_range;

END;

