create
    definer = dsg@localhost procedure DiveDresses_copy1(IN user_id int)
BEGIN
                        SELECT 
            dress,
            COUNT(*) as count
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND dress IS NOT NULL AND DivesInfo.completed =1
            group by dress;
   
   
END;

