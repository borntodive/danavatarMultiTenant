create
    definer = dsg@localhost procedure DivePurpose(IN user_id int)
BEGIN
            SELECT 
            purpose,
            COUNT(*) as count
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND purpose IS NOT NULL AND DivesInfo.completed =1
            group by purpose; 
   
   
END;

