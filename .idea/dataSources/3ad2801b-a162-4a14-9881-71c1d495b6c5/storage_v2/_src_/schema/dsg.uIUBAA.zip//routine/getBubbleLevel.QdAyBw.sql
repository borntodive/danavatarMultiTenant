create
    definer = dsg@localhost procedure getBubbleLevel()
BEGIN
SELECT
	IFNULL(ROUND(time), 'total') AS time,
	IFNULL(eval1, 'total_eval') AS eval,
	COUNT(DivesDopplerEval.eval1) as count
	FROM
	DivesDopplerEval
	WHERE
	eval1=eval2 AND eval2=eval3 AND time < 1000
	GROUP BY  eval1 ASC, time ASC
	WITH ROLLUP;
END;

