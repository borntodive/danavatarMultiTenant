create
    definer = dsg@localhost procedure unactiveUser(IN minPerc int)
BEGIN
SELECT

	u.id,
	u.firstname,
	u.surname,
	u.dan_id,
	u.email,
	IFNULL(dCount, 0) AS dCount,
	IFNULL(dcCount, 0) AS dcCount,
	dcCount*100/dCount as uncompletePerc

FROM
	users u
LEFT JOIN (
	select 

				user_id,
				count(user_id) as dCount
			from DivesInfo
			
			GROUP BY DivesInfo.user_id

	) d ON d.user_id = u.id
LEFT JOIN (
	select 

				user_id,
				count(user_id) as dcCount
			from DivesInfo
			WHERE DivesInfo.completed IS NULL
			GROUP BY DivesInfo.user_id

	) dc ON dc.user_id = u.id
HAVING 
	uncompletePerc > minPerc OR dCount=0;

END;

