create
    definer = dsg@localhost procedure DiveWorkloads(IN user_id int)
BEGIN
            SELECT 
            workload,
            COUNT(*) as count
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND workload IS NOT NULL AND DivesInfo.completed =1
            group by workload;    
   
   
END;

