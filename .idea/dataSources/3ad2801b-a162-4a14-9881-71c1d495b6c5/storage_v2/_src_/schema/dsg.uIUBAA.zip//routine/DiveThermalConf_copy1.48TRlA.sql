create
    definer = dsg@localhost procedure DiveThermalConf_copy1(IN user_id int)
BEGIN
	
           SELECT 
            thermal_conf,
            COUNT(*) as count
            FROM DivesInfo INNER JOIN DivesGenInfo ON DivesInfo.divesGenInfo_id = DivesGenInfo.id
            WHERE DivesGenInfo.user_id=user_id AND thermal_conf IS NOT NULL AND DivesInfo.completed =1
            group by thermal_conf;

END;

