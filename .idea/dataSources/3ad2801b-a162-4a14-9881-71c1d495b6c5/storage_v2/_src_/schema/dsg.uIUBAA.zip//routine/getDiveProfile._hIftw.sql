create
    definer = dsg@localhost procedure getDiveProfile(IN dive_id int)
BEGIN
	SELECT
		ROUND(DivesProfile.time /60,2) as time_min,
		DivesProfile.time as time,
		DivesProfile.depth * -1 as depth,
		DivesProfile.temperature,
		DivesProfile.gasswitch_id,
		DivesProfile.tank_pressure,
		DivesProfile.tank_volume,
		DivesProfile.gf,
		DivesProfile.all_gf
	FROM
		DivesProfile
	WHERE
		DivesProfile.divesInfo_id = dive_id
		
	ORDER BY 
		DivesProfile.time;

END;

