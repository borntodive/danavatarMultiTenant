create view compressed_chunk_stats
            (hypertable_name, chunk_name, compression_status, uncompressed_heap_bytes, uncompressed_index_bytes,
             uncompressed_toast_bytes, uncompressed_total_bytes, compressed_heap_bytes, compressed_index_bytes,
             compressed_toast_bytes, compressed_total_bytes)
as
WITH mapq AS (
    SELECT map.chunk_id,
           pg_size_pretty(map.uncompressed_heap_size)                                                             AS uncompressed_heap_bytes,
           pg_size_pretty(map.uncompressed_index_size)                                                            AS uncompressed_index_bytes,
           pg_size_pretty(map.uncompressed_toast_size)                                                            AS uncompressed_toast_bytes,
           pg_size_pretty(map.uncompressed_heap_size + map.uncompressed_toast_size +
                          map.uncompressed_index_size)                                                            AS uncompressed_total_bytes,
           pg_size_pretty(map.compressed_heap_size)                                                               AS compressed_heap_bytes,
           pg_size_pretty(map.compressed_index_size)                                                              AS compressed_index_bytes,
           pg_size_pretty(map.compressed_toast_size)                                                              AS compressed_toast_bytes,
           pg_size_pretty(map.compressed_heap_size + map.compressed_toast_size +
                          map.compressed_index_size)                                                              AS compressed_total_bytes
    FROM _timescaledb_catalog.compression_chunk_size map
)
SELECT format('%1$I.%2$I'::text, srcht.schema_name, srcht.table_name)::regclass AS hypertable_name,
       format('%1$I.%2$I'::text, srcch.schema_name, srcch.table_name)::regclass AS chunk_name,
       CASE
           WHEN srcch.compressed_chunk_id IS NULL THEN 'Uncompressed'::text
           ELSE 'Compressed'::text
           END                                                                  AS compression_status,
       mapq.uncompressed_heap_bytes,
       mapq.uncompressed_index_bytes,
       mapq.uncompressed_toast_bytes,
       mapq.uncompressed_total_bytes,
       mapq.compressed_heap_bytes,
       mapq.compressed_index_bytes,
       mapq.compressed_toast_bytes,
       mapq.compressed_total_bytes
FROM _timescaledb_catalog.hypertable srcht
         JOIN _timescaledb_catalog.chunk srcch
              ON srcht.id = srcch.hypertable_id AND srcht.compressed_hypertable_id IS NOT NULL AND srcch.dropped = false
         LEFT JOIN mapq ON srcch.id = mapq.chunk_id;

alter table compressed_chunk_stats
    owner to ploi;

