create view compressed_hypertable_stats
            (hypertable_name, total_chunks, number_compressed_chunks, uncompressed_heap_bytes, uncompressed_index_bytes,
             uncompressed_toast_bytes, uncompressed_total_bytes, compressed_heap_bytes, compressed_index_bytes,
             compressed_toast_bytes, compressed_total_bytes)
as
SELECT format('%1$I.%2$I'::text, srcht.schema_name, srcht.table_name)::regclass                                     AS hypertable_name,
       (SELECT count(*) AS count
        FROM _timescaledb_catalog.chunk
        WHERE chunk.hypertable_id = srcht.id)                                                                       AS total_chunks,
       count(*)                                                                                                     AS number_compressed_chunks,
       pg_size_pretty(sum(map.uncompressed_heap_size))                                                              AS uncompressed_heap_bytes,
       pg_size_pretty(sum(map.uncompressed_index_size))                                                             AS uncompressed_index_bytes,
       pg_size_pretty(sum(map.uncompressed_toast_size))                                                             AS uncompressed_toast_bytes,
       pg_size_pretty(sum(map.uncompressed_heap_size) + sum(map.uncompressed_toast_size) +
                      sum(map.uncompressed_index_size))                                                             AS uncompressed_total_bytes,
       pg_size_pretty(sum(map.compressed_heap_size))                                                                AS compressed_heap_bytes,
       pg_size_pretty(sum(map.compressed_index_size))                                                               AS compressed_index_bytes,
       pg_size_pretty(sum(map.compressed_toast_size))                                                               AS compressed_toast_bytes,
       pg_size_pretty(sum(map.compressed_heap_size) + sum(map.compressed_toast_size) +
                      sum(map.compressed_index_size))                                                               AS compressed_total_bytes
FROM _timescaledb_catalog.chunk srcch,
     _timescaledb_catalog.compression_chunk_size map,
     _timescaledb_catalog.hypertable srcht
WHERE map.chunk_id = srcch.id
  AND srcht.id = srcch.hypertable_id
GROUP BY srcht.id;

alter table compressed_hypertable_stats
    owner to ploi;

