create function indexes_relation_size_pretty(main_table regclass)
    returns TABLE(index_name text, total_size text)
    stable
    strict
    language plpgsql
as
$$
BEGIN
        RETURN QUERY
        SELECT s.index_name,
               pg_size_pretty(s.total_bytes)
        FROM public.indexes_relation_size(main_table) s;
END;
$$;

alter function indexes_relation_size_pretty(regclass) owner to ploi;

