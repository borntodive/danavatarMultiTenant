create function main_table_from_hypertable(hypertable_id integer) returns regclass
    stable
    language sql
as
$$
SELECT format('%I.%I',h.schema_name, h.table_name)::regclass
    FROM _timescaledb_catalog.hypertable h
    WHERE id = hypertable_id;
$$;

alter function main_table_from_hypertable(integer) owner to ploi;

