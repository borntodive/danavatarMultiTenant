create view hypertable
            (table_schema, table_name, table_owner, num_dimensions, num_chunks, table_size, index_size, toast_size,
             total_size) as
WITH ht_size AS (
    SELECT ht.id,
           ht.schema_name                   AS table_schema,
           ht.table_name,
           t.tableowner                     AS table_owner,
           ht.num_dimensions,
           (SELECT count(1) AS count
            FROM _timescaledb_catalog.chunk ch
            WHERE ch.hypertable_id = ht.id) AS num_chunks,
           bsize.table_bytes,
           bsize.index_bytes,
           bsize.toast_bytes,
           bsize.total_bytes
    FROM _timescaledb_catalog.hypertable ht
             LEFT JOIN pg_tables t ON ht.table_name = t.tablename AND ht.schema_name = t.schemaname
             LEFT JOIN LATERAL hypertable_relation_size(
            CASE
                WHEN has_schema_privilege(ht.schema_name::text, 'USAGE'::text)
                    THEN format('%I.%I'::text, ht.schema_name, ht.table_name)
                ELSE NULL::text
                END::regclass) bsize(table_bytes, index_bytes, toast_bytes, total_bytes) ON true
),
     compht_size AS (
         SELECT srcht.id,
                sum(map.compressed_heap_size)                                                                   AS heap_bytes,
                sum(map.compressed_index_size)                                                                  AS index_bytes,
                sum(map.compressed_toast_size)                                                                  AS toast_bytes,
                sum(map.compressed_heap_size) + sum(map.compressed_toast_size) +
                sum(map.compressed_index_size)                                                                  AS total_bytes
         FROM _timescaledb_catalog.chunk srcch,
              _timescaledb_catalog.compression_chunk_size map,
              _timescaledb_catalog.hypertable srcht
         WHERE map.chunk_id = srcch.id
           AND srcht.id = srcch.hypertable_id
         GROUP BY srcht.id
     )
SELECT hts.table_schema,
       hts.table_name,
       hts.table_owner,
       hts.num_dimensions,
       hts.num_chunks,
       pg_size_pretty(
               COALESCE(hts.table_bytes::numeric + compht_size.heap_bytes, hts.table_bytes::numeric))         AS table_size,
       pg_size_pretty(COALESCE(hts.index_bytes::numeric + compht_size.index_bytes, hts.index_bytes::numeric,
                               compht_size.index_bytes))                                                      AS index_size,
       pg_size_pretty(COALESCE(hts.toast_bytes::numeric + compht_size.toast_bytes, hts.toast_bytes::numeric,
                               compht_size.toast_bytes))                                                      AS toast_size,
       pg_size_pretty(COALESCE(hts.total_bytes::numeric + compht_size.total_bytes,
                               hts.total_bytes::numeric))                                                     AS total_size
FROM ht_size hts
         LEFT JOIN compht_size ON hts.id = compht_size.id;

alter table hypertable
    owner to ploi;

