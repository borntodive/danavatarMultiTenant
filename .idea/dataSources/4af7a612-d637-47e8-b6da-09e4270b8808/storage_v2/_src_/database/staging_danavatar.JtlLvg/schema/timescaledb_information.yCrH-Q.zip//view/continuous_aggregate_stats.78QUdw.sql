create view continuous_aggregate_stats
            (view_name, completed_threshold, invalidation_threshold, job_id, last_run_started_at,
             last_successful_finish, last_run_status, job_status, last_run_duration, next_scheduled_run, total_runs,
             total_successes, total_failures, total_crashes)
as
SELECT format('%1$I.%2$I'::text, cagg.user_view_schema, cagg.user_view_name)::regclass AS view_name,
       CASE _timescaledb_internal.get_time_type(cagg.raw_hypertable_id)
           WHEN 'timestamp without time zone'::regtype
               THEN _timescaledb_internal.to_timestamp_without_timezone(ct.watermark)::text
           WHEN 'timestamp with time zone'::regtype THEN _timescaledb_internal.to_timestamp(ct.watermark)::text
           WHEN 'date'::regtype THEN _timescaledb_internal.to_date(ct.watermark)::text
           ELSE ct.watermark::text
           END                                                                         AS completed_threshold,
       CASE _timescaledb_internal.get_time_type(cagg.raw_hypertable_id)
           WHEN 'timestamp without time zone'::regtype
               THEN _timescaledb_internal.to_timestamp_without_timezone(it.watermark)::text
           WHEN 'timestamp with time zone'::regtype THEN _timescaledb_internal.to_timestamp(it.watermark)::text
           WHEN 'date'::regtype THEN _timescaledb_internal.to_date(it.watermark)::text
           ELSE it.watermark::text
           END                                                                         AS invalidation_threshold,
       cagg.job_id,
       bgw_job_stat.last_start                                                         AS last_run_started_at,
       bgw_job_stat.last_successful_finish,
       CASE
           WHEN bgw_job_stat.last_finish < '4714-11-24 00:00:00+00 BC'::timestamp with time zone THEN NULL::text
           WHEN bgw_job_stat.last_finish IS NOT NULL THEN
               CASE
                   WHEN bgw_job_stat.last_run_success = true THEN 'Success'::text
                   WHEN bgw_job_stat.last_run_success = false THEN 'Failed'::text
                   ELSE NULL::text
                   END
           ELSE NULL::text
           END                                                                         AS last_run_status,
       CASE
           WHEN bgw_job_stat.last_finish < '4714-11-24 00:00:00+00 BC'::timestamp with time zone THEN 'Running'::text
           WHEN bgw_job_stat.next_start IS NOT NULL THEN 'Scheduled'::text
           ELSE NULL::text
           END                                                                         AS job_status,
       CASE
           WHEN bgw_job_stat.last_finish > bgw_job_stat.last_start
               THEN bgw_job_stat.last_finish - bgw_job_stat.last_start
           ELSE NULL::interval
           END                                                                         AS last_run_duration,
       bgw_job_stat.next_start                                                         AS next_scheduled_run,
       bgw_job_stat.total_runs,
       bgw_job_stat.total_successes,
       bgw_job_stat.total_failures,
       bgw_job_stat.total_crashes
FROM _timescaledb_catalog.continuous_agg cagg
         LEFT JOIN _timescaledb_internal.bgw_job_stat bgw_job_stat ON cagg.job_id = bgw_job_stat.job_id
         LEFT JOIN _timescaledb_catalog.continuous_aggs_invalidation_threshold it
                   ON cagg.raw_hypertable_id = it.hypertable_id
         LEFT JOIN _timescaledb_catalog.continuous_aggs_completed_threshold ct
                   ON cagg.mat_hypertable_id = ct.materialization_id;

alter table continuous_aggregate_stats
    owner to ploi;

