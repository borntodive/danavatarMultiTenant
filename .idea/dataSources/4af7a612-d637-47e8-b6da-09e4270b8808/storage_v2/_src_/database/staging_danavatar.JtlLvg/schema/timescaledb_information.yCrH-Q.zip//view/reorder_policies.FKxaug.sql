create view reorder_policies
            (hypertable, hypertable_index_name, job_id, schedule_interval, max_runtime, max_retries, retry_period) as
SELECT format('%1$I.%2$I'::text, ht.schema_name, ht.table_name)::regclass AS hypertable,
       p.hypertable_index_name,
       p.job_id,
       j.schedule_interval,
       j.max_runtime,
       j.max_retries,
       j.retry_period
FROM _timescaledb_config.bgw_policy_reorder p
         JOIN _timescaledb_catalog.hypertable ht ON p.hypertable_id = ht.id
         JOIN _timescaledb_config.bgw_job j ON p.job_id = j.id;

alter table reorder_policies
    owner to ploi;

