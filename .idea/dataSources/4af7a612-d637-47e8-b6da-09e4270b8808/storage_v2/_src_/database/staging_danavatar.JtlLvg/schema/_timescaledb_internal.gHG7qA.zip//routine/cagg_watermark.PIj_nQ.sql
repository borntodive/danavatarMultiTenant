create function cagg_watermark(hypertable_id oid) returns bigint
    stable
    strict
    language sql
as
$$
SELECT
    watermark
  FROM
    _timescaledb_catalog.continuous_agg cagg
    LEFT JOIN _timescaledb_catalog.continuous_aggs_completed_threshold completed ON completed.materialization_id = cagg.mat_hypertable_id
  WHERE
    cagg.mat_hypertable_id = $1;

$$;

alter function cagg_watermark(oid) owner to ploi;

