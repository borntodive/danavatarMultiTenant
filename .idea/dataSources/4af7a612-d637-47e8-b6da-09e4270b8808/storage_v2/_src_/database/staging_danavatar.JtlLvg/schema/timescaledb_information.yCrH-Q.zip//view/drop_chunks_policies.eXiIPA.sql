create view drop_chunks_policies
            (hypertable, older_than, cascade, job_id, schedule_interval, max_runtime, max_retries, retry_period,
             cascade_to_materializations)
as
SELECT format('%1$I.%2$I'::text, ht.schema_name, ht.table_name)::regclass AS hypertable,
       p.older_than,
       p.cascade,
       p.job_id,
       j.schedule_interval,
       j.max_runtime,
       j.max_retries,
       j.retry_period,
       p.cascade_to_materializations
FROM _timescaledb_config.bgw_policy_drop_chunks p
         JOIN _timescaledb_catalog.hypertable ht ON p.hypertable_id = ht.id
         JOIN _timescaledb_config.bgw_job j ON p.job_id = j.id;

alter table drop_chunks_policies
    owner to ploi;

