create view license(edition, expired, expiration_time) as
SELECT _timescaledb_internal.license_edition()                  AS edition,
       _timescaledb_internal.license_expiration_time() <= now() AS expired,
       _timescaledb_internal.license_expiration_time()          AS expiration_time;

alter table license
    owner to ploi;

